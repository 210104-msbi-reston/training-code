﻿using System;
using System.Threading;
using System.Threading.Tasks;
namespace taskparallelprogram
{
    class Program
    {
        public void reduceProductCount()
        {
                    //this some code and it will take some 20 seconds
                    System.Console.WriteLine("Reduce Product Started");
                    Thread.Sleep(20000);
                    System.Console.WriteLine("Product Reduced");
        }

        public void processPayment()
        {
            System.Console.WriteLine("Payment started");
            Thread.Sleep(80000);
            System.Console.WriteLine("Payment Done");
        }

        public void informPickVendor()
        {
            System.Console.WriteLine("Informing Pickup");
            Thread.Sleep(40000);
            System.Console.WriteLine("Informed");
        }

        public void sendEmail()
        {
            System.Console.WriteLine("Sending Email");
            Thread.Sleep(5000);
            System.Console.WriteLine("Email Sent");
        }

        public void messageToSeller(string message)
        {
            System.Console.WriteLine("Message");
            Thread.Sleep(10000);
            System.Console.WriteLine("Message Done");
        }

        public string ConfirmationNumber()
        {
            System.Console.WriteLine("Confirming started");
            Thread.Sleep(3000);
            System.Console.WriteLine("Confirming Ended");
            return " Order is Confirm";
        }
        public DateTime productArrivalTime()
        {
            System.Console.WriteLine("Arrival started");
            Thread.Sleep(6000);
            System.Console.WriteLine("Arrival Ended");
            return DateTime.Now.AddDays(5);
        }


        static void Main(string[] args)
        {
            Program pObj = new Program();
            // pObj.reduceProductCount();
            // pObj.processPayment();
            // pObj.informPickVendor();
            // pObj.sendEmail();   

            Task reduceProduct = new Task(pObj.reduceProductCount); //just a pointer, 
                                                            //I am not calling the method
            Task payment = new Task(pObj.processPayment);
            Task inform = new Task(pObj.informPickVendor);
            Task email = new Task(pObj.sendEmail);
            
            Task<string> confirm = new Task<string>(pObj.ConfirmationNumber);
            Task<DateTime> arrival = new Task<DateTime>(pObj.productArrivalTime);
            

            // Task message = new Task(pObj.messageToSeller("something"));

            

            reduceProduct.Start();
            payment.Start();
            inform.Start();
            email.Start();
           confirm.Start();
            arrival.Start();
        System.Console.WriteLine("Confirmation " + confirm.Result);
        System.Console.WriteLine("Arriving on " + arrival.Result);








        Console.Read();
        }
    }
}
