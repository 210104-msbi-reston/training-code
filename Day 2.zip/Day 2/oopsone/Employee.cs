using System;
public class Employee
{

   public int test { get; set; }

 //since u did not use it, why did you declare it, you are utilizing the RAM 
    //List of Variables
    int v_empNo;
    string v_empName;
    string v_empDesignation;
    double v_empSalary;

    //Properties
    public int EmployeeNumber
    {
        get{ return v_empNo; }
        set{ v_empNo = value;}
    }

    public string EmployeeName
    {
        get{ return v_empName;}
        set{ v_empName = value;}
    }

    public string EmployeeDesignation
    {
        get{ return v_empDesignation;}
        set{ v_empDesignation = value;}
    }

    public double EmployeeSalary 
    {
        get{return v_empSalary;}
        set{v_empSalary = value;}
    }

    public string GetEmpInfo()
    {
        return this.EmployeeName + " Works as " + this.EmployeeDesignation;
    }
    public double GetSalary()
    {
        return this.EmployeeSalary;
    }
    public double GetBonus(int percentage)
    {
        return (this.EmployeeSalary * percentage) / 100;
    }



}



