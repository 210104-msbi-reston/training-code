﻿using System;
using oopsone;
namespace oopsone
{
   public class Employee
{


 //since u did not use it, why did you declare it, you are utilizing the RAM 
    //List of Variables
    int v_empNo;
    string v_empName;
    string v_empDesignation;
    double v_empSalary;

    //Properties
    public int EmployeeNumber
    {
        get{ return v_empNo; }
        set{ v_empNo = value;}
    }

    public string EmployeeName
    {
        get{ return v_empName;}
        set{ v_empName = value;}
    }

    public string EmployeeDesignation
    {
        get{ return v_empDesignation;}
        set{ v_empDesignation = value;}
    }

    public double EmployeeSalary 
    {
        get{return v_empSalary;}
        set{v_empSalary = value;}
    }

    public string GetEmpInfo()
    {
        return this.EmployeeName + " Works as " + this.EmployeeDesignation;
    }
    public double GetSalary()
    {
        return this.EmployeeSalary;
    }
    public double GetBonus(int percentage)
    {
        return (this.EmployeeSalary * percentage) / 100;
    }



}

        class HR : Employee
        {
            string v_hrType;
            public    string HtType
            {
                get{ return v_hrType; }
                set{ v_hrType = value;}
            }
        }

    class Manager : Employee
    {
         string v_mType;
            public    string ManagerType
            {
                get{ return v_mType; }
                set{ v_mType = value;}
            }
    }
    class Program
    {
        
        static void Main(string[] args)
        {
           // Console.WriteLine("Hello World!");



           HR hrObj = new HR();
            hrObj.HtType = "Technical HR";

            Manager mObj = new Manager();
            
            
        Employee empObj = new Employee();
        Employee empObj2 = new Employee();
        Employee empObj3 = new Employee();
            
        empObj.EmployeeNumber = 101; 
        empObj.EmployeeName = "Nikhil";
        empObj.EmployeeDesignation = "Trainer";
        empObj.EmployeeSalary = 12000;

        Console.WriteLine("~~~~~~~~~~~~ Employee Management Software ~~~~~~~~~~");
        Console.WriteLine("Employee Number : " + empObj.EmployeeNumber);
        Console.WriteLine("Employee Name : " + empObj.EmployeeName);
        Console.WriteLine("Employee Works As  : " + empObj.EmployeeDesignation);
        Console.WriteLine("Employee Annual Salary  : " + empObj.EmployeeSalary * 12);

            Console.WriteLine(empObj.GetEmpInfo());
            Console.WriteLine(empObj.GetSalary());
            Console.WriteLine("Monthly Bonus : " + empObj.GetBonus(25));

        Console.ReadLine();

        }
    }
}
