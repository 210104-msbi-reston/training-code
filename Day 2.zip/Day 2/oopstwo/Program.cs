﻿using System;

namespace oopstwo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

//Old way to create the object
            // Accounts accObj = new Accounts();
            // accObj.accNo = 101;
            // accObj.accName  = "Nik";
            // accObj.accBalance = 6000;
            //i may miss assignment of some propties


            // Accounts accObj = new Accounts(){ accNo=101, accName = "Nik", accBalance = 5000, accCity="Mumbai" };

            // System.Console.WriteLine("Current Balance : " + accObj.accBalance);
            // accObj.Widraw(300);
            
            // System.Console.WriteLine("Balance After Widrawal: " + accObj.accBalance);

            Savings savingsObj = new Savings(){ accNo =  101, accName ="Steve", accCity="Paris", accBalance=8000};
            Loan loanObj = new Loan(){ accNo =  102, accName ="Bill", accCity="Moscow", accBalance=12000};
        //this is not real, and thus should not be allowed
        //Accounts acc = new Accounts(); 

           System.Console.WriteLine(savingsObj.Widraw(200));
           System.Console.WriteLine(loanObj.Widraw(2500));




        }
    }
}
