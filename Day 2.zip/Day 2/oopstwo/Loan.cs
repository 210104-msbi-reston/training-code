public class Loan:Accounts
{
    public override double Widraw(int w_amount)
    {
     if(w_amount > 500)
     {
         //we are suppose to throw an exception
       //  System.Console.WriteLine( "Sorry Limit cannot exceed 500");
        return accBalance;
     }   
     else
     {
         return base.Widraw(w_amount);
     }
    }
}