public abstract class Accounts
{
    //this creates the variables at the time of compilation
    //we as a developer are never suppose to use the varaibles anyways
  public int accNo { get; set; }
  public string accName { get; set; }
  public double accBalance { get; set; }
  public string accCity { get; set; }

  public virtual double Widraw(int w_amount)
  {
      //this is a good practice, when u work with .net 2.0, 
      //.net 2.1 and above, u do not need to use this keyword
      this.accBalance = this.accBalance - w_amount;
      //var a = w_amount - accBalance; //this could be a problem at execution
      return accBalance;
  }

  public double Deposit(int d_amount)
  {
      accBalance = accBalance + d_amount;
      return accBalance;
  }

    
}