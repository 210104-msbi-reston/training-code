﻿using System;

namespace exceptionhandling
{
    class Program
    {
        static void Main(string[] args)
        {
            Savings savObj = new Savings();
            savObj.accBalance = 2000;
            savObj.accBalance = -8900;

    System.Console.WriteLine("Enter First Numer");
                int n1 = Convert.ToInt32(Console.ReadLine());
    System.Console.WriteLine("Enter Second Number");
                int n2 = Convert.ToInt32(Console.ReadLine());

            try
            {
            System.Console.WriteLine(savObj.DivideMyFavNumber(n1,n2));
            }
            catch(DivideByZeroException ex)
            {
                System.Console.WriteLine(ex.Message);
            }

            System.Console.WriteLine("Please Enter Amount to Widraw");
            int amt = Convert.ToInt32(Console.ReadLine());

            try
            {
                  Console.WriteLine(savObj.Widraw(amt));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                
            }
            finally
            {
                System.Console.WriteLine("Thank you for Banking");
            }

         

        Console.ReadLine();

        }
    }
}
