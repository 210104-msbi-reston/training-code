using System;
class Savings
{
    public double accBalance { get; set; }

    private double acBal;
    public double accBal
    {
        get { return acBal; }
        set { 
            if(value < 0)
            {
                throw new Exception("Initital Balance has to be more than 0");
            }
            acBal = value; 
            }
    }
    


    public int DivideMyFavNumber(int firstNumber, int secondNumber)
    {
        if(secondNumber == 0)
        {
            throw new DivideByZeroException("Cannot Divide any number by Zero");
        }
        

        return firstNumber / secondNumber;
    }

    public double Widraw(int amount)
    {
            if(amount > accBalance)
            {
                throw new Exception("Sorry Cannot widraw as you do not have sufficient balance");
            }
            if(amount < 0)
            {
                throw new Exception("Please Enter Only Positive Value");
            }
            if(amount >0 && amount < 100)
            {
                throw new Exception("Please Enter Amount > 100");
            }


        accBalance = accBalance - amount;
        return accBalance;
    }
}