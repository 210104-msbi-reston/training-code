﻿using System;
using System.Collections;
using System.Collections.Generic;
namespace collectionsdemo
{
    class Program
    {
        static void Main(string[] args)
         {

            
        //     int[] myNumbers = new int[5];
        //     myNumbers[0] = 10;
        //     myNumbers[1] = 20;
        //     myNumbers[2] = 40;


        //     System.Console.WriteLine(myNumbers[1]);

            // int[] favNumber = new int[10];
            // int totalEven =0;
            // int totalOdd = 0;
            // int total = 0;
            //     for (int i = 0; i < favNumber.Length; i++)
            //     {
            //         System.Console.WriteLine("Enter Number : " + (i+1));
            //          int number =Convert.ToInt32(Console.ReadLine());
            //          total = total + number;
            //          favNumber[i] = number;
            //         if(number % 2 == 0)
            //         {
            //             totalEven++;
            //         }
            //         else
            //         {
            //             totalOdd++;
            //         }
            //     }
            //     // System.Console.WriteLine( favNumber[7]);

                
            //     Console.Clear();
            //     System.Console.WriteLine("Summary");
            //     System.Console.WriteLine( "Even : " + totalEven);
            //     System.Console.WriteLine("Odds : " + totalOdd);
            //     System.Console.WriteLine("Sum : " + total);

            //     Console.ReadLine();

        //     ArrayList myList = new ArrayList();
        //      int[] myNumbers = new int[5];
        
             
        //     myList.Add(10);
        //     myList.Add(10.5);
        //     myList.Add("Nine");
        //     myList.Add(true);
        //     // myList.Add(new Employee(){});
        //     myList.Add(myNumbers);
        //        myList.Add(10);
        //     myList.Add(10.5);
        //     myList.Add("Nine");
        //     myList.Add(true);
        //        myList.Add(10);
        //     myList.Add(10.5);
        //     myList.Add("Nine");
        //     myList.Add(true);
        //        myList.Add(10);
        //     myList.Add(10.5);
        //     myList.Add("Nine");
        //     myList.Add(true);

        //     foreach (var item in myList)
        //     {
        //         System.Console.WriteLine(item);
        //     }

        // System.Console.WriteLine("Total Strength " + myList.Count);
        // Console.ReadLine();

        // List<int> favNumbers = new List<int>();
        // favNumbers.Add(10);
        // favNumbers.Add(20);
        // favNumbers.Add(30);
        // favNumbers.Add(40);
        // favNumbers.Add(50);
        // favNumbers.Add(60);
        // favNumbers.Add(70);
        // favNumbers.Add(80);
              // favNumbers.Add(30);

        // foreach (var item in favNumbers)
        // {
        //     System.Console.WriteLine(item);
        // }

       
    //    SortedList friends = new SortedList();
    //    friends.Add("Steve");
    //    friends.Add("")
    //generics
    // Dictionary<int,string> guestList = new Dictionary<int, string>();
    // guestList.Add(101,"Steve");
    // guestList.Add(102,"Steve");
    // guestList.Add(103,"Steve");
    // guestList.Add(103,"Steve");

    // Hashtable guestList2 = new Hashtable();
    // guestList2.Add("one","Nikhil");
    // guestList2.Add(2,"Bill");
    // guestList2.Add("Donald",3);

    // SortedList<int,string> friends = new System.Collections.Generic.SortedList<int,string>();
    // friends.Add(8,"Donald");
    // friends.Add(10,"Steve");
    // friends.Add(3,"Adam");
    // friends.Add(14,"Zac");
    // friends.Add(55,"Zuker");



    // foreach (var item in friends)
    // {
    //         System.Console.WriteLine(item.);
    // }
    // for (int i = 0; i <= friends.Count ; i++)
    // {
    //     System.Console.WriteLine(friends.GetValueList());
    // }

    // foreach (var item in friends)
    // {
    //     System.Console.WriteLine(item.Key);
    // }

    List<Employee> empList  = new List<Employee>()
    {
        new Employee(){ empNo=101, empName ="Steve", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="Bill", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="Donald", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="Putin", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="Modi", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="Andrew", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="Tom", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="Leo", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="Heath", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="Mark", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="XingP", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="Nikhil", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
        new Employee(){ empNo=101, empName ="Ronaldo", empCity="NYK", empDesignation="Chair Person", empSalary=90000},
    };


        foreach (var item in empList)
        {
            System.Console.WriteLine(item.empName);
            item.HikeSalary();
            System.Console.WriteLine(item.empSalary);
        }
        System.Console.WriteLine("Total : " + empList.Count);


        Hashtable clients = new Hashtable();
        clients.Add(10,"Infosys");
        clients.Add("One","Cog");
        
        Dictionary<int,string> clientnames = new Dictionary<int, string>();
      
   // SortedList<int,string> myfriends = new SortedList<int, string>();





        
        }
    }
}









