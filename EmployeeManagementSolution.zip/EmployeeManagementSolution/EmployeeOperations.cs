using System;
using System.Data.SqlClient;
public class EmployeeOperations
{

    public int AddEmployee()
    {
         Console.WriteLine("Employee Management");
            SqlConnection con =new SqlConnection("server=trainer\\NYKSERVER;database=EmployeeManagementDB;integrated security=true"); 
            SqlCommand cmdObj = new SqlCommand("insert into EmployeeInformation values(@newEmpNo,@newEmpName,@newEmpDesignation,@newEmpSal,@newEmpCity,@newEmpIsPermenant)",con);

            System.Console.WriteLine("Enter New Employee Number");
            int newEmpNo =Convert.ToInt32( Console.ReadLine());

            System.Console.WriteLine("Enter New Employee Name");
            string newEmpName = Console.ReadLine();

            System.Console.WriteLine("Enter New Employee Designation");
            string newEmpDesignation = Console.ReadLine();

            System.Console.WriteLine("Enter New Employee Salary");
            int newEmpSalary = Convert.ToInt32(Console.ReadLine());

            System.Console.WriteLine("Enter New Employee City");
            string newEmpCity = Console.ReadLine();

            System.Console.WriteLine("Enter New Employee is Permenant");
            bool newEmpIsPermenant = Convert.ToBoolean(Console.ReadLine());

            cmdObj.Parameters.AddWithValue("@newEmpNo",newEmpNo);
            cmdObj.Parameters.AddWithValue("@newEmpName",newEmpName);
            cmdObj.Parameters.AddWithValue("@newEmpDesignation",newEmpDesignation);
            cmdObj.Parameters.AddWithValue("@newEmpSal",newEmpSalary);
            cmdObj.Parameters.AddWithValue("@newEmpCity",newEmpCity);
            cmdObj.Parameters.AddWithValue("@newEmpIsPermenant",newEmpIsPermenant);
            con.Open();
             int result =    cmdObj.ExecuteNonQuery(); //no of rown 
            con.Close();

            System.Console.WriteLine("Employee Added To System Successfully");
            Console.ReadLine();

            return result;
            
    }


    public int DeleteEmployee()
    {
        SqlConnection con = new SqlConnection("server=trainer\\NYKServer;database=EmployeeManagementDB ;integrated security=true");
        SqlCommand cmd = new SqlCommand("delete from EmployeeInformation where empId=@eNo",con);
      
        System.Console.WriteLine("Enter Employee Number");
        int empNo = Convert.ToInt32(Console.ReadLine());

        cmd.Parameters.AddWithValue("@eNo",empNo);

        con.Open();
            int result = cmd.ExecuteNonQuery();
        con.Close();
        return result;
    }

    public int UpdateEmployee()
    {
 SqlConnection con = new SqlConnection("server=trainer\\NYKServer;database=EmployeeManagementDB ;integrated security=true");
        SqlCommand cmd = new SqlCommand("update EmployeeInformation set empSalary =@newsal where empId=@eNo",con);

        System.Console.WriteLine("Enter Employee No");
        int no = Convert.ToInt32(Console.ReadLine());

    System.Console.WriteLine("Enter New Salary");
        int sal = Convert.ToInt32(Console.ReadLine());

        cmd.Parameters.AddWithValue("@newsal",sal);
        cmd.Parameters.AddWithValue("@eNo",no);
        
       con.Open();
            int result = cmd.ExecuteNonQuery();
        con.Close();
        return result;

    }


    public string GetEmployee()
    {

        SqlConnection con = new SqlConnection("server=trainer\\NYKServer;database=EmployeeManagementDB ;integrated security=true");
        SqlCommand cmd = new SqlCommand("select * from  EmployeeInformation where empId=@eNo",con);
SqlDataReader read = null;
string result = "";
        System.Console.WriteLine("Enter Employee No");
        int no = Convert.ToInt32(Console.ReadLine());
          cmd.Parameters.AddWithValue("@eNo",no);
        
        try
        {
       con.Open();

       read =  cmd.ExecuteReader();

        
                if(read.Read())
                {
                 result  = "Employee No : " + read[0] + 
                                 "\n Employee Name : " + read[1] +
                                 "\n Employee Designation : " + read[2] +
                                 "\n Employee Salary : " + read[3] +
                                 "\n Employee City : " + read[4] +
                                 "\n Employee Is Permenant : " + read[5];

                }
                else
                {
                        result = "Employee Does Not Exist, Please Verify the EmpNo";
                }   
        }
        catch(SqlException sqlexp)
        {
            throw new Exception(sqlexp.Message);
        }
        finally
        {
            read.Close();
            con.Close();
        }             

           
         return result;


    }

    


}