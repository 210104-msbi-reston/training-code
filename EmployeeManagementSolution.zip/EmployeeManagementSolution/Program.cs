﻿using System;
using System.Data.SqlClient;
namespace EmployeeManagementSolution
{
    class Program
    {


        static void Main(string[] args)
        {
                bool continueoptions = true;

while(continueoptions)
{
            System.Console.WriteLine("Welcome to Employee Management Solution");
           EmployeeOperations operationObj = new EmployeeOperations();
           System.Console.WriteLine("-------------------------- Choose From Below Option ----------");
           Console.WriteLine("1. View Employee");
           Console.WriteLine("2. Add Employee");
           Console.WriteLine("3. Delete Employee");
           Console.WriteLine("4. Update Employee");
           Console.WriteLine("5. Exit");

           int choice = Convert.ToInt32(Console.ReadLine());

           switch (choice)
           {
              case 1:
                string result = operationObj.GetEmployee();
                System.Console.WriteLine(result);
                break;

              case 2:
                operationObj.AddEmployee();
                break;

                 case 3:
                operationObj.DeleteEmployee();
                System.Console.WriteLine("Employee Deleted Successfully");
                break;

                 case 4:
                operationObj.UpdateEmployee();
                System.Console.WriteLine("Employee Updated Successfully");
                break;

                 case 5:
                    System.Console.WriteLine("Thank you for Using My Solution");
                        
                break;
               default:
                    System.Console.WriteLine("Sorry Invalid Option");
                    break;
                
           }

           System.Console.WriteLine("Do you Want to Continue ?");
           System.Console.WriteLine("1. Yes \n 2. No"); 
            int choose = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            if(choose == 2) { continueoptions = false; }
           
}
           


        }
    }
}
