﻿using System;

namespace singleTonConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            IChat obj1 = ClsGetChatObj.GetObj();
            obj1.setData("Nikhil is My Name");   // we set teh data in first ojt

            IChat obj2 = ClsGetChatObj.GetObj();
           System.Console.WriteLine(obj2.getData()); //this is another obj accessigng the data

            IChat obj3 = ClsGetChatObj.GetObj();
            System.Console.WriteLine(obj3.getData());

        }
    }
}
