﻿using System;

namespace loanApplicationConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            ILoan loan;

            loan = LoanFactory.LoanApplication(LoanType.Home);
            System.Console.WriteLine(loan.applyLoan());

            loan = LoanFactory.LoanApplication(LoanType.Personal);
            System.Console.WriteLine(loan.applyLoan());

            
            loan = LoanFactory.LoanApplication(LoanType.Vehicle);
            System.Console.WriteLine(loan.applyLoan());

            loan = LoanFactory.LoanApplication(LoanType.Education);
            System.Console.WriteLine( loan.applyLoan());




            

        }
    }
}
