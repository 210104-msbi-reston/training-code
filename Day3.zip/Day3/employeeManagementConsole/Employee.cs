public class Employee
{
    //by default static int are set to 0 
    //by default int are set to null
    static int v_autoNumber = 100; 
    public int empNo { get; set; }
    public string empName { get; set; }
    public string empDesignation { get; set; }
    public double empSalary { get; set; }

    public Employee(string _name, string _designation, double _salary)
    {
        //after have the name check and other validation check
        empName = _name;
        empDesignation = _designation;
        empSalary = _salary;

        v_autoNumber++;
        empNo = v_autoNumber;
    }

    

}