﻿using System;

namespace employeeManagementConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee("Richard", "Sales", 8000);
            Employee emp2 = new Employee("PC", "Manager", 12000);
            Employee emp3 = new Employee("PC", "Manager", 12000);
            Employee emp4 = new Employee("PC", "Manager", 12000);
            Employee emp5 = new Employee("PC", "Manager", 12000);
            Employee emp6 = new Employee("PC", "Manager", 12000);
            Employee emp7 = new Employee("PC", "Manager", 12000);

            System.Console.WriteLine(emp1.empNo);
            System.Console.WriteLine(emp2.empNo);
            System.Console.WriteLine(emp3.empNo);
            System.Console.WriteLine(emp4.empNo);
            System.Console.WriteLine(emp5.empNo);
            System.Console.WriteLine(emp6.empNo);

        }
    }
}
