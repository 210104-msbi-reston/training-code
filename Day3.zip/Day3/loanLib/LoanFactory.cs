public class LoanFactory
{
        public static ILoan LoanApplication(LoanType type)
    {   
            switch (type)
            { 
                case LoanType.Home:
                    return new Home();
                case LoanType.Personal:
                    return new Personal();
                case LoanType.Vehicle:
                    return new Vehicle();  
                case LoanType.Education:
                    return new Education();                
                default:
                    return null;
            }

    }

}