public class Education : ILoan
{
    public string applyLoan()
    {
        return "Educational Loan applied for";
    }
}