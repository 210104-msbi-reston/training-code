public class Personal : ILoan
{       
    public string applyLoan()
    {
        return "Personal Loan is Applied";
    }
}