public class Vehicle:ILoan
{
    public string applyLoan()
    {
        return "Vehicle Loan is Applied";
    }
}