
public enum LoanType
{
    Personal,
    Vehicle,
    Home,
    Education
}

public interface ILoan
{
    string applyLoan();
}