﻿using System;

namespace loanLib
{
    public class Class1
    {
    }
}
