public class Home:ILoan
{
    public string applyLoan()
    {
            return "Home Loan Applied";
    }
}