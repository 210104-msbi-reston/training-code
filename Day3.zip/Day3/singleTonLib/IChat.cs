public interface IChat
{
    void setData(string val);
    string getData();
}