public class Chat : IChat
{
    string name="";
    public static int  counter = 0;

    public Chat()
    {   
        counter = 1;
    }
    public void setData(string val)
    {
            name = val;
    }
    public string getData()
    {
         return name;
    }


}