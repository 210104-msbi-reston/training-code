public class ClsGetChatObj
{

    static Chat obj; //this is the single ton 


//if the chat object is in not in system, a new object will be created and the same wil
//be used throughout the application
        public static IChat GetObj()
        {   
                if(Chat.counter == 0)
                {
                    obj = new Chat();
                }
                return obj;
        }
}

